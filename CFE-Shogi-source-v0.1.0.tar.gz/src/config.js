// Copy this file to your deployment as-is and fill the public Supabase values.
// Only the project URL and publishable key belong here. Never put service_role here.
export const SUPABASE_URL = '';
export const SUPABASE_PUBLISHABLE_KEY = '';
