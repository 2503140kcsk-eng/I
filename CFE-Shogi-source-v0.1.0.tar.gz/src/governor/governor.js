const RESOURCE_KEYS = ['cpuMs', 'gpuMs', 'memoryMiB', 'energyJ', 'heatUnits'];

function finiteNonNegative(value, label) {
  if (!Number.isFinite(value) || value < 0) throw new TypeError(`${label} must be finite and non-negative`);
  return value;
}

/**
 * Selects one bounded computation by estimated immediate + amortized reuse value
 * minus priced resource costs. This is a deterministic policy primitive, not a
 * learned VOC model. Resource prices must be calibrated by the host runtime.
 */
export function selectComputation(actions, options = {}) {
  if (!Array.isArray(actions)) throw new TypeError('actions must be an array');
  const rho = finiteNonNegative(options.reuseWeight ?? 0, 'reuseWeight');
  const prices = options.prices ?? {};
  const budget = options.budget ?? {};
  const eligible = [];

  for (const action of actions) {
    if (!action || typeof action.id !== 'string') continue;
    const now = finiteNonNegative(action.deltaUNow ?? 0, `${action.id}.deltaUNow`);
    const reuse = finiteNonNegative(action.deltaUReuse ?? 0, `${action.id}.deltaUReuse`);
    const costs = action.costs ?? {};
    let cost = 0;
    let withinBudget = true;
    for (const key of RESOURCE_KEYS) {
      const amount = finiteNonNegative(costs[key] ?? 0, `${action.id}.costs.${key}`);
      const price = finiteNonNegative(prices[key] ?? 0, `prices.${key}`);
      if (budget[key] !== undefined && amount > finiteNonNegative(budget[key], `budget.${key}`)) withinBudget = false;
      cost += amount * price;
    }
    if (!withinBudget) continue;
    eligible.push({ ...action, score: now + rho * reuse - cost });
  }

  eligible.sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
  if (eligible.length === 0 || eligible[0].score <= 0) return null;
  return eligible[0];
}

export function estimateThermalBudget(samples, config = {}) {
  // PWA-safe estimator: infer sustainable work from observed latency/throughput.
  // Browsers do not expose a portable physical temperature sensor.
  const windowSize = Math.max(3, Math.floor(config.windowSize ?? 8));
  const values = (Array.isArray(samples) ? samples : [])
    .filter((value) => Number.isFinite(value) && value > 0)
    .slice(-windowSize);
  if (values.length < 3) return { state: 'unknown', multiplier: 1, samples: values.length };
  const first = values[0];
  const last = values[values.length - 1];
  const ratio = last / first;
  if (ratio >= 1.35) return { state: 'degraded', multiplier: 0.45, samples: values.length, ratio };
  if (ratio >= 1.15) return { state: 'warming', multiplier: 0.7, samples: values.length, ratio };
  return { state: 'stable', multiplier: 1, samples: values.length, ratio };
}

export const GOVERNOR_RESOURCE_KEYS = RESOURCE_KEYS;
