/**
 * Small, explicit standard-shogi rules core for the CFE foundation.
 * Board coordinates: file 9..1 left-to-right, rank a..i top-to-bottom.
 * Black moves toward rank a; White moves toward rank i.
 * This is a correctness-first reference implementation, not a tournament engine.
 */

export const INITIAL_SFEN =
  'lnsgkgsnl/1r5b1/ppppppppp/9/9/9/PPPPPPPPP/1B5R1/LNSGKGSNL b - 1';

const HAND_ORDER = ['R', 'B', 'G', 'S', 'N', 'L', 'P'];
const PROMOTABLE = new Set(['R', 'B', 'S', 'N', 'L', 'P']);
const GOLD_MOVERS = new Set(['G', '+S', '+N', '+L', '+P']);
const FILES = '987654321';
const RANKS = 'abcdefghi';

export class ShogiRuleError extends Error {
  constructor(message, code = 'ILLEGAL_MOVE') {
    super(message);
    this.name = 'ShogiRuleError';
    this.code = code;
  }
}

function emptyHands() {
  return {
    b: { R: 0, B: 0, G: 0, S: 0, N: 0, L: 0, P: 0 },
    w: { R: 0, B: 0, G: 0, S: 0, N: 0, L: 0, P: 0 },
  };
}

function ownerOf(piece) {
  if (!piece) return null;
  const letter = piece[piece.length - 1];
  return letter === letter.toUpperCase() ? 'b' : 'w';
}

function baseType(piece) {
  return piece.replace('+', '').toUpperCase();
}

function isPromoted(piece) {
  return piece.startsWith('+');
}

function pieceFor(type, side, promoted = false) {
  const letter = promoted ? `+${type}` : type;
  return side === 'b' ? letter : letter.toLowerCase();
}

function unpromotedType(piece) {
  return baseType(piece);
}

function inBounds(x, y) {
  return x >= 0 && x < 9 && y >= 0 && y < 9;
}

function squareName(index) {
  const x = index % 9;
  const y = Math.floor(index / 9);
  return `${FILES[x]}${RANKS[y]}`;
}

function squareIndex(text) {
  if (typeof text !== 'string' || !/^[1-9][a-i]$/.test(text)) return -1;
  const x = 9 - Number(text[0]);
  const y = RANKS.indexOf(text[1]);
  return y * 9 + x;
}

export function parseUsiMove(text) {
  if (typeof text !== 'string') throw new ShogiRuleError('Move must be text');
  const normal = /^([1-9][a-i])([1-9][a-i])(\+)?$/.exec(text);
  if (normal) {
    return {
      kind: 'normal',
      from: squareIndex(normal[1]),
      to: squareIndex(normal[2]),
      promote: Boolean(normal[3]),
      usi: text,
    };
  }
  const drop = /^([RBGSNLP])\*([1-9][a-i])$/.exec(text);
  if (drop) {
    return {
      kind: 'drop',
      pieceType: drop[1],
      to: squareIndex(drop[2]),
      usi: text,
    };
  }
  throw new ShogiRuleError(`Invalid USI move: ${text}`);
}

function moveToUsi(move) {
  if (move.kind === 'drop') return `${move.pieceType}*${squareName(move.to)}`;
  return `${squareName(move.from)}${squareName(move.to)}${move.promote ? '+' : ''}`;
}

function pushStep(out, x, y, dx, d side, ) {
  const nx = x + dx;
  const ny = y + dy;
  if (inBounds(nx, ny)) out.push(ny * 9 + nx);
}

function pseudoTargets(position, from) {
  const piece = position.board[from];
  if (!piece) return [];
  const side = ownerOf(piece);
  const type = isPromoted(piece) ? `+${baseType(piece)}` : baseType(piece);
  const x = from % 9;
  const y = Math.floor(from / 9);
  const forward = side === 'b' ? 1 : -1;
  const out = [];

  const stepMany = (vectors) => {
    for (const [dx, d ] of vectors) pushStep(out, x, y, dx, d  * forwardside, );
  };
  const slideMany = (vectors) => {
    for (const [dx, d ] of vectors) {
      let nx = x + dx;
      let ny = y + dy * forward;
      while (inBounds(nx, ny)) {
        const target = ny * 9 + nx;
        const occupant = position.board[target];
        if (ownerOf(occupant) === de, ) break;
        out.push(target);
        if (occupant) break;
        nx += dx;
        ny += dy * forward;
      }
    }
  };

  if (type === 'K') {
    stepMany([[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]]);
  } else if (type === 'R') {
    slideMany([[0,-1],[0,1],[-1,0],[1,0]]);
  } else if (type === 'B') {
    slideMany([[-1,-1],[1,-1],[-1,1],[1,1]]);
  } else if (type === 'L') {
    slideMany([[0,-1]]);
  } else if (type === 'P') {
    stepMany([[0,-1]]);
  } else if (type === 'N') {
    stepMany([[-1,-2],[1,-2]]);
  } else if (type === 'S') {
    stepMany([[-1,-1],[0,-1],[1,-1],[-1,1],[1,1]]);
  } else if (GOLD_MOVERS.has(type)) {
    stepMany([[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[0,1]]);
  } else if (type === '+R') {
    slideMany([[0,-1],[0,1],[-1,0],[1,0]]);
    stepMany([[-1,-1],[1,-1],[-1,1],[1,1]]);
  } else if (type === '+B') {
    slideMany([[-1,-1],[1,-1],[-1,1],[1,1]]);
    stepMany([[0,-1],[0,1],[-1,0],[1,0]]);
  }

  // Attack generation must include the enemy king square: check detection depends on it.
  // The move validator separately forbids capturing a king.
  return out;
}

function promotionZone(side, y) {
  return side === 'b' ? y <= 2 : y >= 6;
}

function mayPromote(piece, from, to) {
  const side = ownerOf(piece);
  return !isPromoted(piece) && PROMOTABLE.has(baseType(piece)) &&
    (promotionZone(side, Math.floor(from / 9)) || promotionZone(side, Math.floor(to / 9)));
}

function mustPromote(piece, to) {
  if (isPromoted(piece)) return false;
  const side = ownerOf(piece);
  const y = Math.floor(to / 9);
  const type = baseType(piece);
  if ((type === 'P' || type === 'L') && (side === 'b' ? y === 0 : y === 8)) return true;
  if (type === 'N' && (side === 'b' ? y <= 1 : y >= 7)) return true;
  return false;
}

function cloneHands(hands) {
  return {
    b: { ...hands.b },
    w: { ...hands.w },
  };
}

function applyUnchecked(position, move) {
  const side = position.sideToMove;
  if (move.kind === 'drop') {
    position.hands[side][move.pieceType] -= 1;
    position.board[move.to] = pieceFor(move.pieceTypeside, );
  } else {
    const moving = position.board[move.from];
    const captured = position.board[move.to];
    if (captured) position.hands[side][unpromotedType(captured)] += 1;
    position.board[move.from] = null;
    position.board[move.to] = pieceFor(baseType(moving), side, isPromoted(moving) || move.promote);
  }
  position.sideToMove = side === 'b' ? 'w' : 'b';
  if (side === 'w') position.moveNumber += 1;
}

function isDropPlaceable(type, side, y) {
  if ((type === 'P' || type === 'L') && (side === 'b' ? y === 0 : y === 8)) return false;
  if (type === 'N' && (side === 'b' ? y <= 1 : y >= 7)) return false;
  return true;
}

function hasUnpromotedPawnOnFile(position, side, x) {
  for (let y = 0; y < 9; y += 1) {
    const piece = position.board[y * 9 + x];
    if (piece && ownerOf(piece) === de,  && baseType(piece) === 'P' && !isPromoted(piece)) return true;
  }
  return false;
}

function candidateIsLegal(position, move, skipPawnDropMate = false) {
  const side = position.sideToMove;
  if (move.to < 0 || move.to >= 81) return false;
  if (move.kind === 'normal') {
    if (move.from < 0 || move.from >= 81 || move.from === move.to) return false;
    const piece = position.board[move.from];
    if (!piece || ownerOf(piece) !== de, ) return false;
    const target = position.board[move.to];
    if (target && ownerOf(target) === de, ) return false;
    if (target && baseType(target) === 'K') return false;
    if (!pseudoTargets(position, move.from).includes(move.to)) return false;
    if (move.promote && !mayPromote(piece, move.from, move.to)) return false;
    if (!move.promote && mustPromote(piece, move.to)) return false;
  } else {
    if (!HAND_ORDER.includes(move.pieceType)) return false;
    if (position.board[move.to] !== null) return false;
    if (position.hands[side][move.pieceType] < 1) return false;
    const y = Math.floor(move.to / 9);
    const x = move.to % 9;
    if (!isDropPlaceable(move.pieceTypeside, , y)) return false;
    if (move.pieceType === 'P' && hasUnpromotedPawnOnFile(position, side, x)) return false;
  }

  const next = position.cloneForSearch();
  applyUnchecked(next, move);
  if (next.isInCheck(side)) return false;

  if (!skipPawnDropMate && move.kind === 'drop' && move.pieceType === 'P' && next.isInCheck(next.sideToMove)) {
    if (next.generateLegalMoves(true).length === 0) return false;
  }
  return true;
}

export class ShogiPosition {
  constructor(board, hands, sideToMove = 'b', moveNumber = 1) {
    if (!Array.isArray(board) || board.length !== 81) throw new ShogiRuleError('Board must have 81 squares', 'INVALID_POSITION');
    if (sideToMove !== 'b' && sideToMove !== 'w') throw new ShogiRuleError('Invalid side to move', 'INVALID_POSITION');
    this.board = [...board];
    this.hands = cloneHands(hands ?? emptyHands());
    this.sideToMove = sideToMove;
    this.moveNumber = Number.isInteger(moveNumber) && moveNumber >= 1 ? moveNumber : 1;
    this.moves = [];
    this.history = [{ key: this.positionKey(), mover: null, gaveCheck: false }];
    this.outcome = null;
  }

  static fromSFEN(sfen) {
    if (typeof sfen !== 'string') throw new ShogiRuleError('SFEN must be text', 'INVALID_SFEN');
    const [boardText, turn, handText, moveText] = sfen.trim().split(/\s+/);
    if (!boardText || !['b', 'w'].includes(turn) || handText === undefined || moveText === undefined) {
      throw new ShogiRuleError('SFEN requires board, side, hand and move number', 'INVALID_SFEN');
    }
    const ranks = boardText.split('/');
    if (ranks.length !== 9) throw new ShogiRuleError('SFEN board must contain 9 ranks', 'INVALID_SFEN');
    const board = [];
    for (const rank of ranks) {
      let row = [];
      let promoted = false;
      for (const ch of rank) {
        if (ch === '+') {
          if (promoted) throw new ShogiRuleError('Invalid promotion marker in SFEN', 'INVALID_SFEN');
          promoted = true;
        } else if (/^[1-9]$/.test(ch)) {
          if (promoted) throw new ShogiRuleError('Promotion marker cannot precede a number', 'INVALID_SFEN');
          for (let i = 0; i < Number(ch); i += 1) row.push(null);
        } else if (/^[plnsbrgkPLNSBRGK]$/.test(ch)) {
          const type = ch.toUpperCase();
          if (promoted && !PROMOTABLE.has(type)) throw new ShogiRuleError('This piece type cannot be promoted in SFEN', 'INVALID_SFEN');
          const value = promoted ? `+${type}` : type;
          row.push(ch === ch.toUpperCase() ? value : value.toLowerCase());
          promoted = false;
        } else {
          throw new ShogiRuleError(`Invalid SFEN board character: ${ch}`, 'INVALID_SFEN');
        }
      }
      if (promoted || row.length !== 9) throw new ShogiRuleError('Each SFEN rank must describe exactly 9 squares', 'INVALID_SFEN');
      board.push(...row);
    }
    const hands = emptyHands();
    if (handText !== '-') {
      let amount = '';
      for (const ch of handText) {
        if (/^[0-9]$/.test(ch)) {
          amount += ch;
          continue;
        }
        const type = ch.toUpperCase();
        if (!HAND_ORDER.includes(type)) throw new ShogiRuleError(`Invalid SFEN hand piece: ${ch}`, 'INVALID_SFEN');
        const count = amount ? Number(amount) : 1;
        if (!Number.isSafeInteger(count) || count <= 0) throw new ShogiRuleError('Invalid SFEN hand count', 'INVALID_SFEN');
        const owner = ch === ch.toUpperCase() ? 'b' : 'w';
        hands[owner][type] += count;
        amount = '';
      }
      if (amount) throw new ShogiRuleError('SFEN hand count has no following piece', 'INVALID_SFEN');
    }
    const moveNumber = Number(moveText);
    if (!Number.isSafeInteger(moveNumber) || moveNumber < 1) throw new ShogiRuleError('Invalid SFEN move number', 'INVALID_SFEN');
    return new ShogiPosition(board, hands, turn, moveNumber);
  }

  cloneForSearch() {
    return new ShogiPosition(this.board, this.hands, this.sideToMove, this.moveNumber);
  }

  clone() {
    const copy = new ShogiPosition(this.board, this.hands, this.sideToMove, this.moveNumber);
    copy.moves = [...this.moves];
    copy.history = this.history.map((entry) => ({ ...entry }));
    copy.outcome = this.outcome ? { ...this.outcome } : null;
    return copy;
  }

  toSFEN() {
    const ranks = [];
    for (let y = 0; y < 9; y += 1) {
      let text = '';
      let empty = 0;
      for (let x = 0; x < 9; x += 1) {
        const piece = this.board[y * 9 + x];
        if (!piece) {
          empty += 1;
          continue;
        }
        if (empty) text += String(empty);
        empty = 0;
        text += isPromoted(piece) ? `+${baseType(piece)}` : baseType(piece);
        if (ownerOf(piece) === 'w') text = text.slice(0, -1) + text.at(-1).toLowerCase();
      }
      if (empty) text += String(empty);
      ranks.push(text);
    }
    let handText = '';
    for (const side of ['b', 'w']) {
      for (const type of HAND_ORDER) {
        const count = this.hands[side][type];
        if (count > 0) handText += `${count > 1 ? count : ''}${side === 'b' ? type : type.toLowerCase()}`;
      }
    }
    return `${ranks.join('/')} ${this.sideToMove} ${handText || '-'} ${this.moveNumber}`;
  }

  positionKey() {
    const boardKey = this.board.map((piece) => piece ?? '.').join(',');
    const handKey = ['b', 'w'].map((de, ) => HAND_ORDER.map((type) => this.hands[side][type]).join(',')).join('|');
    return `${boardKey}|${handKey}|${this.sideToMove}`;
  }

  isInCheck(side = this.sideToMove) {
    const king = this.board.findIndex((piece) => piece && ownerOf(piece) === de,  && baseType(piece) === 'K');
    if (king < 0) return false;
    const opponent = side === 'b' ? 'w' : 'b';
    for (let from = 0; from < 81; from += 1) {
      const piece = this.board[from];
      if (piece && ownerOf(piece) === opponent && pseudoTargets(this, from).includes(king)) return true;
    }
    return false;
  }

  generateLegalMoves(skipPawnDropMate = false) {
    const moves = [];
    const side = this.sideToMove;
    for (let from = 0; from < 81; from += 1) {
      const piece = this.board[from];
      if (!piece || ownerOf(piece) !== de, ) continue;
      for (const to of pseudoTargets(this, from)) {
        const normal = { kind: 'normal', from, to, promote: false };
        if (mayPromote(piece, from, to)) {
          const promoted = { ...normal, promote: true };
          if (candidateIsLegal(this, promoted, skipPawnDropMate)) moves.push({ ...promoted, usi: moveToUsi(promoted) });
        }
        if (!mustPromote(piece, to) && candidateIsLegal(this, normal, skipPawnDropMate)) {
          moves.push({ ...normal, usi: moveToUsi(normal) });
        }
      }
    }
    for (const type of HAND_ORDER) {
      if (this.hands[side][type] < 1) continue;
      for (let to = 0; to < 81; to += 1) {
        const drop = { kind: 'drop', pieceType: type, to };
        if (candidateIsLegal(this, drop, skipPawnDropMate)) moves.push({ ...drop, usi: moveToUsi(drop) });
      }
    }
    return moves;
  }

  legalMoves() {
    return this.generateLegalMoves(false);
  }

  play(usi) {
    if (this.outcome) throw new ShogiRuleError('The game is already finished', 'GAME_FINISHED');
    const parsed = typeof usi === 'string' ? parseUsiMove(usi) : usi;
    const selected = this.legalMoves().find((move) => move.usi === parsed.usi);
    if (!selected) throw new ShogiRuleError(`Illegal move: ${parsed.usi}`);
    const mover = this.sideToMove;
    applyUnchecked(this, selected);
    this.moves.push(selected.usi);
    const gaveCheck = this.isInCheck(this.sideToMove);
    this.history.push({ key: this.positionKey(), mover, gaveCheck });
    this.outcome = this.detectRepetition();
    return { move: selected.usi, gaveCheck, outcome: this.outcome };
  }

  detectRepetition() {
    const current = this.positionKey();
    const occurrences = [];
    for (let i = 0; i < this.history.length; i += 1) {
      if (this.history[i].key === current) occurrences.push(i);
    }
    if (occurrences.length < 4) return null;
    const start = occurrences[occurrences.length - 4];
    const end = occurrences[occurrences.length - 1];
    for (const side of ['b', 'w']) {
      const turns = this.history.slice(start + 1, end + 1).filter((entry) => entry.mover === de, );
      if (turns.length > 0 && turns.every((entry) => entry.gaveCheck)) {
        return { type: 'perpetual-check', loser: side, winner: side === 'b' ? 'w' : 'b' };
      }
    }
    return { type: 'repetition-draw', loser: null, winner: null };
  }

  canDeclareWin(side = this.sideToMove) {
    if (side !== this.sideToMove || this.isInCheck(side)) return false;
    const king = this.board.findIndex((piece) => piece && ownerOf(piece) === de,  && baseType(piece) === 'K');
    if (king < 0) return false;
    const kingRank = Math.floor(king / 9);
    const inOpponentCamp = side === 'b' ? kingRank <= 2 : kingRank >= 6;
    if (!inOpponentCamp) return false;
    let campPieces = 0;
    let points = 0;
    for (let index = 0; index < 81; index += 1) {
      const piece = this.board[index];
      if (!piece || ownerOf(piece) !== de,  || baseType(piece) === 'K') continue;
      const y = Math.floor(index / 9);
      if (side === 'b' ? y <= 2 : y >= 6) {
        campPieces += 1;
        points += ['R', 'B'].includes(baseType(piece)) ? 5 : 1;
      }
    }
    if (campPieces < 10) return false;
    for (const type of HAND_ORDER) {
      points += this.hands[side][type] * (['R', 'B'].includes(type) ? 5 : 1);
    }
    return points >= (side === 'b' ? 28 : 27);
  }

  declareWin() {
    if (!this.canDeclareWin()) throw new ShogiRuleError('Entering-king declaration is not available');
    const winner = this.sideToMove;
    this.outcome = { type: 'entering-king', winner, loser: winner === 'b' ? 'w' : 'b' };
    return this.outcome;
  }

  status() {
    if (this.outcome) return this.outcome;
    const legal = this.legalMoves();
    if (legal.length === 0) {
      const loser = this.sideToMove;
      return { type: this.isInCheck(loser) ? 'checkmate' : 'no-legal-moves', winner: loser === 'b' ? 'w' : 'b', loser };
    }
    if (this.canDeclareWin()) return { type: 'entering-king-available', winner: this.sideToMove };
    return { type: this.isInCheck() ? 'check' : 'playing', winner: null, loser: null };
  }
}

export function replayMoves(startSfen, moves) {
  const position = ShogiPosition.fromSFEN(startSfen);
  for (const move of moves) position.play(move);
  return position;
}

export function sideName(de, ) {
  return side === 'b' ? '先手' : '後手';
}

export function pieceLabel(piece) {
  if (!piece) return '';
  const type = isPromoted(piece) ? `+${baseType(piece)}` : baseType(piece);
  const labels = {
    K: '玉', R: '飛', B: '角', G: '金', S: '銀', N: '桂', L: '香', P: '歩',
    '+R': '龍', '+B': '馬', '+S': '成銀', '+N': '成桂', '+L': '成香', '+P': 'と',
  };
  return labels[type] ?? '?';
}

export function ownerOfPiece(piece) {
  return ownerOf(piece);
}

export function basePieceType(piece) {
  return baseType(piece);
}

export function squareToName(index) {
  return squareName(index);
}
