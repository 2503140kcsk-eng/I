import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from '../config.js';

export function isOnlineConfigured() {
  return /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(SUPABASE_URL) &&
    typeof SUPABASE_PUBLISHABLE_KEY === 'string' && SUPABASE_PUBLISHABLE_KEY.length > 12;
}

let sdkPromise;
export async function createOnlineClient() {
  if (!isOnlineConfigured()) throw new Error('オンライン機能には src/config.js のSupabase設定が必要です');
  sdkPromise ??= import('https://esm.sh/@supabase/supabase-js@2.119.2?bundle');
  const { createClient } = await sdkPromise;
  return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
}

export async function requestMagicLink(client, email) {
  const { error } = await client.auth.signInWithOtp({
    email,
    options: {
      shouldCreateUser: true,
      emailRedirectTo: `${location.origin}${location.pathname}`,
    },
  });
  if (error) throw error;
}

export async function createInviteRoom(client) {
  const { data, error } = await client.rpc('create_invite_game');
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.game_id || !row?.invite_code) throw new Error('対局室を作成できませんでした');
  return row;
}

export async function joinInviteRoom(client, inviteCode) {
  const { data, error } = await client.rpc('join_invite_game', { p_invite_code: inviteCode.trim().toUpperCase() });
  if (error) throw error;
  if (!data) throw new Error('対局室に参加できませんでした');
  return data;
}

export async function loadOnlineGame(client, gameId) {
  const { data: game, error: gameError } = await client.from('games')
    .select('id, invite_code, black_player, white_player, status, initial_sfen, current_sfen, move_count, result, created_at, updated_at')
    .eq('id', gameId).maybeSingle();
  if (gameError) throw gameError;
  if (!game) throw new Error('対局が見つからないか、閲覧権限がありません');
  const { data: moves, error: movesError } = await client.from('game_moves')
    .select('ply, side, usi_move, sfen_after, player_id, created_at')
    .eq('game_id', gameId).order('ply', { ascending: true });
  if (movesError) throw movesError;
  return { game, moves: moves ?? [] };
}

export async function listMyGames(client) {
  const { data, error } = await client.from('games')
    .select('id, status, black_player, white_player, move_count, result, updated_at')
    .order('updated_at', { ascending: false }).limit(30);
  if (error) throw error;
  return data ?? [];
}

export async function sendOnlineMove(client, gameId, usiMove) {
  const { data, error } = await client.functions.invoke('submit-move', {
    body: { game_id: gameId, usi_move: usiMove },
  });
  if (error) throw error;
  if (!data?.ok) throw new Error(data?.error ?? '着手を保存できませんでした');
  return data;
}

export function subscribeToGame(client, gameId, onChange) {
  const channel = client.channel(`game-updates:${gameId}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'games', filter: `id=eq.${gameId}` }, onChange)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'game_moves', filter: `game_id=eq.${gameId}` }, onChange)
    .subscribe();
  return () => client.removeChannel(channel);
}
