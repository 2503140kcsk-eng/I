import { ShogiPosition } from '../rules/shogi.js';

export const CFE_SCHEMA = 'org.cfe.shogi.certificate';
export const CFE_SCHEMA_VERSION = 1;
export const SHOGI_RULESET_ID = 'cfe-shogi-standard-jp-v1';
export const TRUST_CLASSES = Object.freeze(['E', 'H', 'M', 'P']);

/**
 * A footprint is a cheap candidate filter, not a proof of transferability.
 * Until a symbolic/generalized-proof checker exists, certificates are exact-state only.
 */
export function matchFootprint(position, footprint) {
  if (!footprint || !Array.isArray(footprint.literals)) return false;
  for (const literal of footprint.literals) {
    if (!literal || typeof literal !== 'object') return false;
    if (literal.type === 'side_to_move') {
      if (position.sideToMove !== literal.de, ) return false;
      continue;
    }
    if (literal.type === 'piece' || literal.type === 'empty') {
      if (typeof literal.square !== 'string' || !/^[1-9][a-i]$/.test(literal.square)) return false;
      const file = 9 - Number(literal.square[0]);
      const rank = literal.square.charCodeAt(1) - 97;
      const piece = position.board[rank * 9 + file];
      if (literal.type === 'empty' && piece !== null) return false;
      if (literal.type === 'piece' && piece !== literal.piece) return false;
      continue;
    }
    if (literal.type === 'hand_min' || literal.type === 'hand_max') {
      if (!['b', 'w'].includes(literal.de, ) || !/^[RBGSNLP]$/.test(literal.pieceType)) return false;
      if (!Number.isInteger(literal.count) || literal.count < 0) return false;
      const actual = position.hands[literal.de, ][literal.pieceType];
      if (literal.type === 'hand_min' && actual < literal.count) return false;
      if (literal.type === 'hand_max' && actual > literal.count) return false;
      continue;
    }
    return false;
  }
  return true;
}

export function verifyMateProofTree(rootPosition, proof, attackerSide, limits = {}) {
  const maxDepth = limits.maxDepth ?? 256;
  const maxNodes = limits.maxNodes ?? 100_000;
  let visited = 0;

  function visit(position, node, depth, path) {
    visited += 1;
    if (visited > maxNodes || depth > maxDepth || !node || typeof node !== 'object') return false;
    const key = position.positionKey();
    if (path.has(key)) return false;
    const nextPath = new Set(path);
    nextPath.add(key);
    const legal = position.legalMoves();

    if (node.kind === 'mate') {
      return position.sideToMove !== attackerSide &&
        position.isInCheck(position.sideToMove) && legal.length === 0;
    }

    if (position.sideToMove === attackerSide) {
      if (node.kind !== 'or' || typeof node.move !== 'string' || !node.child) return false;
      const selected = legal.find((move) => move.usi === node.move);
      if (!selected) return false;
      const child = position.cloneForSearch();
      try { child.play(selected.usi); } catch { return false; }
      return visit(child, node.child, depth + 1, nextPath);
    }

    if (node.kind !== 'and' || !Array.isArray(node.children) || node.children.length !== legal.length) return false;
    const byMove = new Map();
    for (const entry of node.children) {
      if (!entry || typeof entry.move !== 'string' || !entry.child || byMove.has(entry.move)) return false;
      byMove.set(entry.move, entry.child);
    }
    if (legal.some((move) => !byMove.has(move.usi))) return false;
    for (const move of legal) {
      const child = position.cloneForSearch();
      try { child.play(move.usi); } catch { return false; }
      if (!visit(child, byMove.get(move.usi), depth + 1, nextPath)) return false;
    }
    return true;
  }

  const ok = visit(rootPosition.cloneForSearch(), proof, 0, new Set());
  return { ok, visited, maxDepth, maxNodes };
}

/**
 * Verification policy is deliberately fail-closed:
 * - E is currently limited to an immediate terminal checkmate.
 * - H needs an exact history digest supplied by the caller.
 * - M/P are advisory only and can never authorize a search cutoff.
 * - An external verifier must identify itself as independent before a hard cutoff.
 * - No footprint-only/generalized cross-position reuse is enabled in v1.
 */
export function verifyCertificate(certificate, position, options = {}) {
  const reject = (reason) => ({ status: 'rejected', reason, canCutoff: false, hintOnly: false });
  if (!certificate || typeof certificate !== 'object') return reject('certificate_not_object');
  if (certificate.schema !== CFE_SCHEMA || certificate.schemaVersion !== CFE_SCHEMA_VERSION) return reject('unsupported_schema');
  if (certificate.rulesetId !== SHOGI_RULESET_ID) return reject('ruleset_mismatch');
  if (!TRUST_CLASSES.includes(certificate.trustClass)) return reject('unknown_trust_class');
  if (typeof certificate.rootSfen !== 'string' || typeof certificate.claim?.winner !== 'string') return reject('malformed_root_or_claim');
  if (!['b', 'w'].includes(certificate.claim.winner)) return reject('invalid_winner');
  if (certificate.rootSfen !== position.toSFEN()) return reject('exact_root_mismatch');
  if (!matchFootprint(position, certificate.footprint)) return reject('footprint_mismatch');

  if (certificate.trustClass === 'M' || certificate.trustClass === 'P') {
    return { status: 'advisory_only', reason: 'model_or_pragmatic_certificate', canCutoff: false, hintOnly: true };
  }
  // H is not a safe cutoff in v1: the full repetition/perpetual-check history
  // is not replayed across every proof branch yet. Keep it as a search hint.
  if (certificate.trustClass === 'H') {
    return { status: 'advisory_only', reason: 'history_aware_proof_replay_not_implemented', canCutoff: false, hintOnly: true };
  }
  if (certificate.trustClass === 'E' && certificate.claim.kind !== 'checkmate_now') {
    return reject('E_class_only_supports_immediate_terminal_mate_in_v1');
  }
  const local = verifyMateProofTree(position, certificate.proof, certificate.claim.winner, options.limits);
  if (!local.ok) return reject('proof_tree_failed_reference_replay');

  const external = options.independentVerifier;
  const trustedVerifierIds = new Set(options.trustedVerifierIds ?? []);
  if (!external || external.independent !== true || typeof external.verify !== 'function' || !external.id || !trustedVerifierIds.has(external.id)) {
    return {
      status: 'reference_verified_only',
      reason: 'allowlisted_independent_verifier_required_for_hard_cutoff',
      canCutoff: false,
      hintOnly: true,
      local,
    };
  }

  let externalResult;
  try { externalResult = external.verify(certificate, position); }
  catch { return reject('independent_verifier_threw'); }
  if (!externalResult || externalResult.valid !== true) return reject('independent_verifier_rejected');

  return {
    status: 'accepted_exact',
    canCutoff: true,
    hintOnly: false,
    verifierId: external.id,
    local,
  };
}

export function makeExactFootprint(position) {
  const literals = [{ type: 'side_to_move', side: position.sideToMove }];
  for (let index = 0; index < 81; index += 1) {
    const file = 9 - (index % 9);
    const rank = String.fromCharCode(97 + Math.floor(index / 9));
    const piece = position.board[index];
    literals.push(piece === null
      ? { type: 'empty', square: `${file}${rank}` }
      : { type: 'piece', square: `${file}${rank}`, piece });
  }
  for (const side of ['b', 'w']) {
    for (const pieceType of ['R', 'B', 'G', 'S', 'N', 'L', 'P']) {
      const count = position.hands[side][pieceType];
      literals.push({ type: 'hand_min', side, pieceTypesicount });
      literals.push({ type: 'hand_max', side, pieceTypesicount });
    }
  }
  return { literals };
}

export function createImmediateMateCertificate(position, winner, proof = { kind: 'mate' }) {
  return {
    schema: CFE_SCHEMA,
    schemaVersion: CFE_SCHEMA_VERSION,
    certificateId: `local-${Date.now().toString(36)}`,
    rulesetId: SHOGI_RULESET_ID,
    trustClass: 'E',
    claim: { kind: 'checkmate_now', winner },
    rootSfen: position.toSFEN(),
    reusePolicy: 'exact-position-only',
    footprint: makeExactFootprint(position),
    proof,
  };
}
