/* Classic worker wrapper for the official YaneuraOu Emscripten output. */
let engine = null;
let initializing = false;

self.addEventListener('message', async (event) => {
  const message = event.data ?? {};
  if (message.type === 'init') {
    if (engine || initializing) return;
    initializing = true;
    try {
      importScripts('./wasm/yaneuraou.halfkp.js');
      const factory = self.YaneuraOu_HalfKP;
      if (typeof factory !== 'function') throw new Error('YaneuraOu_HalfKP factory was not exported');
      engine = await factory({
        locateFile: (path) => new URL(`./wasm/${path}`, self.location.href).href,
        print: (line) => self.postMessage({ type: 'line', line: String(line) }),
      });
      if (typeof engine.addMessageListener === 'function') {
        engine.addMessageListener((line) => self.postMessage({ type: 'line', line: String(line) }));
      }
      self.postMessage({ type: 'ready' });
    } catch (error) {
      self.postMessage({ type: 'error', error: error?.message ?? String(error) });
    } finally {
      initializing = false;
    }
    return;
  }

  if (message.type === 'command') {
    if (!engine) {
      self.postMessage({ type: 'error', error: 'engine_not_initialized' });
      return;
    }
    if (typeof message.command !== 'string' || message.command.length > 512) return;
    engine.postMessage(message.command);
  }

  if (message.type === 'terminate') {
    try { engine?.postMessage('quit'); } catch { /* terminate regardless */ }
    try { engine?.terminate?.(); } catch { /* worker will still terminate */ }
    self.close();
  }
});
