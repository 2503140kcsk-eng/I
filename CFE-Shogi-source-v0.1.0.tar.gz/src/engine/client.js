/**
 * Browser-side USI client for the optional YaneuraOu halfkp WASM build.
 * It intentionally has no fallback that pretends a missing engine is available.
 */
export class YaneuraOuClient {
  constructor(options = {}) {
    this.workerUrl = options.workerUrl ?? new URL('./worker.js', import.meta.url);
    this.worker = null;
    this.listeners = new Set();
    this.waiters = new Set();
    this.started = false;
  }

  onLine(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  _handleMessage(message) {
    if (message?.type === 'error') {
      for (const waiter of [...this.waiters]) waiter.reject(new Error(message.error || 'engine_worker_error'));
      this.waiters.clear();
      return;
    }
    if (message?.type === 'ready') {
      this._emit('ready');
      for (const waiter of [...this.waiters]) {
        if (waiter.predicate('ready')) {
          this.waiters.delete(waiter);
          waiter.resolve('ready');
        }
      }
      return;
    }
    if (message?.type === 'line' && typeof message.line === 'string') {
      const line = message.line.trim();
      this._emit(line);
      for (const waiter of [...this.waiters]) {
        if (waiter.predicate(line)) {
          this.waiters.delete(waiter);
          waiter.resolve(line);
        }
      }
    }
  }

  _emit(line) {
    for (const listener of this.listeners) {
      try { listener(line); } catch { /* observer failures do not break engine I/O */ }
    }
  }

  _waitFor(predicate, timeoutMs = 30000) {
    return new Promise((resolve, reject) => {
      const waiter = { predicate, resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        this.waiters.delete(waiter);
        reject(new Error('engine_response_timeout'));
      }, timeoutMs);
      const originalResolve = waiter.resolve;
      const originalReject = waiter.reject;
      waiter.resolve = (value) => { clearTimeout(waiter.timer); originalResolve(value); };
      waiter.reject = (error) => { clearTimeout(waiter.timer); originalReject(error); };
      this.waiters.add(waiter);
    });
  }

  _send(command) {
    if (!this.worker) throw new Error('engine_not_started');
    this.worker.postMessage({ type: 'command', command });
  }

  async start() {
    if (this.started) return;
    if (typeof Worker === 'undefined') throw new Error('このブラウザではWeb Workerを利用できません');
    this.worker = new Worker(this.workerUrl, { type: 'classic', name: 'cfe-yaneuraou' });
    this.worker.addEventListener('message', (event) => this._handleMessage(event.data));
    this.worker.addEventListener('error', (event) => {
      const error = new Error(event.message || 'engine_worker_failed');
      for (const waiter of [...this.waiters]) waiter.reject(error);
      this.waiters.clear();
    });

    const ready = this._waitFor((line) => line === 'ready', 90000);
    this.worker.postMessage({ type: 'init' });
    await ready;

    const usiok = this._waitFor((line) => line === 'usiok', 30000);
    this._send('usi');
    await usiok;

    this._send('setoption name Threads value 1');
    this._send('setoption name Hash value 64');
    this._send('usinewgame');
    const readyok = this._waitFor((line) => line === 'readyok', 30000);
    this._send('isready');
    await readyok;
    this.started = true;
  }

  async bestMove(sfen, depth = 8) {
    if (!this.started) throw new Error('engine_not_ready');
    if (typeof sfen !== 'string' || sfen.length > 256) throw new TypeError('invalid_sfen');
    const safeDepth = Math.max(1, Math.min(20, Math.floor(Number(depth) || 8)));
    this._send(`position sfen ${sfen}`);
    const bestmove = this._waitFor((line) => line.startsWith('bestmove '), 120000);
    this._send(`go depth ${safeDepth}`);
    const line = await bestmove;
    const match = /^bestmove\s+(\S+)/.exec(line);
    if (!match) throw new Error('engine_returned_malformed_bestmove');
    return match[1];
  }

  stopSearch() {
    if (this.started) this._send('stop');
  }

  close() {
    if (this.worker) {
      try { this.worker.postMessage({ type: 'terminate' }); } catch { /* ignore */ }
      this.worker.terminate();
    }
    this.worker = null;
    this.started = false;
    for (const waiter of [...this.waiters]) waiter.reject(new Error('engine_closed'));
    this.waiters.clear();
  }
}
